document.getElementById("searchForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const keyword = document.getElementById("keyword").value.trim();
    const resultDiv = document.getElementById("result");
    resultDiv.innerHTML = "⏳ Đang tìm kiếm...";

    try {
        // Gọi API Node-RED backend
        const response = await fetch(`http://localhost:1880/timkiem?q=${encodeURIComponent(keyword)}`);
        const data = await response.json();

        if (data.length === 0) {
            resultDiv.innerHTML = `<p>❌ Không tìm thấy sản phẩm nào phù hợp!</p>`;
            return;
        }

        // Hiển thị kết quả
        let html = "";
        data.forEach(item => {
            html += `
                <div class="product">
                    <h3>${item.Ten}</h3>
                    <p><b>Giá:</b> ${item.Gia.toLocaleString()} VNĐ</p>
                    <p><b>Mô tả:</b> ${item.MoTa}</p>
                </div>
            `;
        });
        resultDiv.innerHTML = html;
    } catch (error) {
        console.error("Lỗi:", error);
        resultDiv.innerHTML = `<p style="color:red;">⚠️ Không thể kết nối đến server!</p>`;
    }
});
